package Main;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

public class Display {
	
	private BorderPane screen;
	private HBox hbox;
	private StackPane stackPane;
	private Canvas canvas;
	private GraphicsContext gc;
	
	Display(){
		
		screen = new BorderPane();
        screen.setPadding(new Insets(5,5,5,5));
        hbox = new HBox();
        stackPane = new StackPane(hbox);         // Add stack to HBox in top region
        canvas = new Canvas(600,400);
        gc = canvas.getGraphicsContext2D();
        screen.setCenter(canvas);
        
        //use for backgorund
        //screen.setBackground(new Background(new BackgroundFill(Color.PURPLE, null, null)));
        //gc.setFill(Color.GREEN);
        //gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight()); 
        
        
	}
	
	public void setArea(Text a, char place) {
		
		if (place == 't') {
			screen.setTop(a);
		}
		else if (place == 'c') {
			screen.setCenter(a);
		}

		else if (place == 'l') {
			screen.setLeft(a);
		}

		else if (place == 'r') {
			screen.setRight(a);
		}

		else if (place == 'b') {
			screen.setBottom(a);
		}
		
	}
	public void setArea(Button a, char place) {
		
		if (place == 't') {
			screen.setTop(a);
		}
		else if (place == 'c') {
			screen.setCenter(a);
		}

		else if (place == 'l') {
			screen.setLeft(a);
		}

		else if (place == 'r') {
			screen.setRight(a);
		}

		else if (place == 'b') {
			screen.setBottom(a);
		}
		
	}
	public void setArea(VBox a, char place) {
		
		if (place == 't') {
			screen.setTop(a);
		}
		else if (place == 'c') {
			screen.setCenter(a);
		}

		else if (place == 'l') {
			screen.setLeft(a);
		}

		else if (place == 'r') {
			screen.setRight(a);
		}

		else if (place == 'b') {
			screen.setBottom(a);
		}
		
	}
	public void setArea(ImageView a, char place) {
		
		if (place == 't') {
			screen.setTop(a);
		}
		else if (place == 'c') {
			screen.setCenter(a);
		}

		else if (place == 'l') {
			screen.setLeft(a);
		}

		else if (place == 'r') {
			screen.setRight(a);
		}

		else if (place == 'b') {
			screen.setBottom(a);
		}
		
	}	
	public void setAlignment (Text a, String place) {
		if( (place == "tl") || (place == "TOP_LEFT")   ) {
			screen.setAlignment(a,Pos.TOP_LEFT);
		}
		else if( (place == "tc") || (place == "TOP_CENTER")   ) {
			screen.setAlignment(a,Pos.TOP_CENTER);
		}else if( (place == "tr") || (place == "TOP_RIGHT")   ) {
			screen.setAlignment(a,Pos.TOP_RIGHT);
		}else if( (place == "cl") || (place == "CENTER_LEFT")   ) {
			screen.setAlignment(a,Pos.CENTER_LEFT);
		}else if( (place == "c") || (place == "CENTER")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "cr") || (place == "CENTER_RIGHT")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "bl") || (place == "BOTTOM_LEFT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_LEFT);
		}else if( (place == "br") || (place == "BOTTOM_RIGHT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_RIGHT);
		}else if( (place == "bC") || (place == "BOTTOM_CENTER")   ) {
			screen.setAlignment(a,Pos.BOTTOM_CENTER);
		}else if( (place == "bl") || (place == "BASELINE_LEFT")   ) {
			screen.setAlignment(a,Pos.BASELINE_LEFT);
		}else if( (place == "bc") || (place == "BASELINE_CENTER")   ) {
			screen.setAlignment(a,Pos.BASELINE_CENTER);
		}else if( (place == "br") || (place == "BASELINE_RIGHT")   ) {
			screen.setAlignment(a,Pos.BASELINE_RIGHT);
		}
		
	}
	public void setAlignment (Button a, String place) {
		if( (place == "tl") || (place == "TOP_LEFT")   ) {
			screen.setAlignment(a,Pos.TOP_LEFT);
		}
		else if( (place == "tc") || (place == "TOP_CENTER")   ) {
			screen.setAlignment(a,Pos.TOP_CENTER);
		}else if( (place == "tr") || (place == "TOP_RIGHT")   ) {
			screen.setAlignment(a,Pos.TOP_RIGHT);
		}else if( (place == "cl") || (place == "CENTER_LEFT")   ) {
			screen.setAlignment(a,Pos.CENTER_LEFT);
		}else if( (place == "c") || (place == "CENTER")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "cr") || (place == "CENTER_RIGHT")   ) {
			screen.setAlignment(a,Pos.CENTER_RIGHT);
		}else if( (place == "bl") || (place == "BOTTOM_LEFT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_LEFT);
		}else if( (place == "br") || (place == "BOTTOM_RIGHT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_RIGHT);
		}else if( (place == "bC") || (place == "BOTTOM_CENTER")   ) {
			screen.setAlignment(a,Pos.BOTTOM_CENTER);
		}else if( (place == "bsl") || (place == "BASELINE_LEFT")   ) {
			screen.setAlignment(a,Pos.BASELINE_LEFT);
		}else if( (place == "bc") || (place == "BASELINE_CENTER")   ) {
			screen.setAlignment(a,Pos.BASELINE_CENTER);
		}else if( (place == "br") || (place == "BASELINE_RIGHT")   ) {
			screen.setAlignment(a,Pos.BASELINE_RIGHT);
		}
		
	}
	public void setAlignment (VBox a, String place) {
		if( (place == "tl") || (place == "TOP_LEFT")   ) {
			screen.setAlignment(a,Pos.TOP_LEFT);
		}
		else if( (place == "tc") || (place == "TOP_CENTER")   ) {
			screen.setAlignment(a,Pos.TOP_CENTER);
		}else if( (place == "tr") || (place == "TOP_RIGHT")   ) {
			screen.setAlignment(a,Pos.TOP_RIGHT);
		}else if( (place == "cl") || (place == "CENTER_LEFT")   ) {
			screen.setAlignment(a,Pos.CENTER_LEFT);
		}else if( (place == "c") || (place == "CENTER")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "cr") || (place == "CENTER_RIGHT")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "bl") || (place == "BOTTOM_LEFT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_LEFT);
		}else if( (place == "br") || (place == "BOTTOM_RIGHT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_RIGHT);
		}else if( (place == "bC") || (place == "BOTTOM_CENTER")   ) {
			screen.setAlignment(a,Pos.BOTTOM_CENTER);
		}else if( (place == "bl") || (place == "BASELINE_LEFT")   ) {
			screen.setAlignment(a,Pos.BASELINE_LEFT);
		}else if( (place == "bc") || (place == "BASELINE_CENTER")   ) {
			screen.setAlignment(a,Pos.BASELINE_CENTER);
		}else if( (place == "br") || (place == "BASELINE_RIGHT")   ) {
			screen.setAlignment(a,Pos.BASELINE_RIGHT);
		}
		
	}
	public void setAlignment (ImageView a, String place) {
		if( (place == "tl") || (place == "TOP_LEFT")   ) {
			screen.setAlignment(a,Pos.TOP_LEFT);
		}
		else if( (place == "tc") || (place == "TOP_CENTER")   ) {
			screen.setAlignment(a,Pos.TOP_CENTER);
		}else if( (place == "tr") || (place == "TOP_RIGHT")   ) {
			screen.setAlignment(a,Pos.TOP_RIGHT);
		}else if( (place == "cl") || (place == "CENTER_LEFT")   ) {
			screen.setAlignment(a,Pos.CENTER_LEFT);
		}else if( (place == "c") || (place == "CENTER")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "cr") || (place == "CENTER_RIGHT")   ) {
			screen.setAlignment(a,Pos.CENTER);
		}else if( (place == "bl") || (place == "BOTTOM_LEFT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_LEFT);
		}else if( (place == "br") || (place == "BOTTOM_RIGHT")   ) {
			screen.setAlignment(a,Pos.BOTTOM_RIGHT);
		}else if( (place == "bC") || (place == "BOTTOM_CENTER")   ) {
			screen.setAlignment(a,Pos.BOTTOM_CENTER);
		}else if( (place == "bl") || (place == "BASELINE_LEFT")   ) {
			screen.setAlignment(a,Pos.BASELINE_LEFT);
		}else if( (place == "bc") || (place == "BASELINE_CENTER")   ) {
			screen.setAlignment(a,Pos.BASELINE_CENTER);
		}else if( (place == "br") || (place == "BASELINE_RIGHT")   ) {
			screen.setAlignment(a,Pos.BASELINE_RIGHT);
		}
		
	}
	
	public Canvas getCanvas() {
		return canvas;
	}
	public void addSprite() {
		
	}
	public BorderPane getScreen() {
		return screen;
	}
	public void addImage(Image img,int x, int y, int width, int height) {
		gc.drawImage(img,x,y,width,height);
		
		
	}
	public void changeBackground(int numb) {

        gc.setFill(Color.GREEN);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight()); 
        screen.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        if(numb == 2) {
        screen.setBackground(new Background(new BackgroundFill(Color.PURPLE, null, null)));
        }
	}
	
}
