package Main;

public class Progress {
	private int genTrig;
	private int upTrig;
	private Display screen;
	private Sprite phoenix1;
	private Sprite phoenix2;
	private Sprite phoenix3;
	private Sprite phoenix4;
	private Sprite phoenix5;
	private Sprite gym;
	private Sprite bagels;
	private Sprite chowHall;
	private Sprite IST;
	private Sprite polybuck;
	
	
	Progress(){
		genTrig = 0;
		upTrig = 0;
		loadImages();
		changeScene();
	}
	Progress(Display d){
		genTrig = 0;
		upTrig = 0;
		screen = d;
		loadImages();
		changeScene();
	}
	public void setGenTrig(int numb){
		if(numb > genTrig) {
			genTrig = numb;
		}
			changeScene();
		
	}
	public void setUpTrig(int numb) {
		if(numb > upTrig) {
			upTrig = numb;
		}
			changeScene();
		
	}
	
	public void setDisplay(Display d) {
		screen = d;
	}
	
	protected void loadImages() {
        phoenix1 = new Sprite("Sprites/phoenix.png",150,150);
        phoenix2 = new Sprite("Sprites/phoenix_glass_fire.png",190,190);
        phoenix3 = new Sprite("Sprites/phoenix_glassRandom.png",220,220);
        phoenix4 = new Sprite("Sprites/phoenix_glassRandom_fire.png",260,260);
        phoenix5 = new Sprite("Sprites/phoenix_fire.png",300,300);
         gym= new Sprite("Sprites/gym.png",200,200);
         bagels= new Sprite("Sprites/bagels.png",200,200);
         chowHall= new Sprite("Sprites/chowHall.png",200,200);
         IST= new Sprite("Sprites/IST.png",200,200);
         polybuck= new Sprite("Sprites/polybucks.png",200,200);
	}
	
	
	public void changeScene() {
		
	//background color triggers
	if( (genTrig + upTrig) > 6 ) {
		screen.changeBackground(2);
	}	
	else if ( (genTrig + upTrig) > 3 ) {
		screen.changeBackground(1);
	}
		
	//change phoenix sprites
	switch(upTrig) {
	case 0:
			break;
	case 1:
	       screen.addImage(phoenix1.getImage(), (300 - phoenix1.getWidth()/2) , 0, phoenix1.getWidth(), phoenix1.getHeight());
		break;
	case 2:
        screen.addImage(phoenix2.getImage(), (300 - phoenix2.getWidth()/2), 0, phoenix2.getWidth(), phoenix2.getHeight());
		break;
	case 3:
		screen.addImage(phoenix3.getImage(), (300 - phoenix3.getWidth()/2), 0, phoenix3.getWidth(), phoenix3.getHeight());
		break;
	case 4:
        screen.addImage(phoenix4.getImage(), (300 - phoenix4.getWidth()/2), 0, phoenix4.getWidth(), phoenix4.getHeight());
		break;
	case 5:
        screen.addImage(phoenix5.getImage(), (300 - phoenix5.getWidth()/2), 0, phoenix5.getWidth(), phoenix5.getHeight());
		break;
	
	}
	switch(genTrig) {
	case 4:screen.addImage(gym.getImage(),  0,220 , gym.getWidth(), gym.getHeight());
	case 3:screen.addImage(polybuck.getImage(), 100 ,220 , polybuck.getWidth(), polybuck.getHeight());
	case 2:screen.addImage(bagels.getImage(), 400 ,0 , bagels.getWidth(), bagels.getHeight());
	case 1:screen.addImage(IST.getImage(), 300 ,220 , IST.getWidth(), IST.getHeight());
	case 0:screen.addImage(chowHall.getImage(), 0 ,0 , chowHall.getWidth(), chowHall.getHeight());
		break;
	
	
	
	
	
	
	}
		
		
		
		
		
	}
}
