package Main;

public class ClickButton {

    //Button Variables
    private int btnValue = 1;
    private int btnMulti;
    private int btnTotal;

    //Upgrade Variables
    private String[] serText = new String[4];
    private int[] serCost = new int[4];
    private int serPlace;

    public int serLength = 4;

    ClickButton(String text[], int uCost[]) {
        btnMulti = 1;

        for (int i = 0; i < serLength; i++) {
            serText[i] = text[i];
            serCost[i] = uCost[i];
        }
        serPlace = 0;
    }

    ClickButton(String text[], int uCost[], int place) {
        btnMulti = 1;

        for (int i = 0; i < serLength; i++) {
            serText[i] = text[i];
            serCost[i] = uCost[i];
        }
        serPlace = place;
    }

    //Button Functions
    public int getBtnTotal() {
        btnTotal = btnValue * btnMulti;
        return btnTotal;
    }

    //Upgrade Functions
    public int getSerPlace() {
        return serPlace;
    }

    public String getSerText() {
        return serText[serPlace];
    }

    public int getSerCost() {
        return serCost[serPlace];
    }

    boolean isDone = false;

    public long serBuy(long counter) {
        if (serPlace == 3 && counter >= serCost[serPlace]) {
            counter -= serCost[serPlace];
            isDone = true;
        } else if (counter >= serCost[serPlace]) {
            counter -= serCost[serPlace];
            serPlace += 1;
            btnMulti = (serPlace + 1) * 2;
        }
        return counter;
    }

    public void update() {
        btnMulti = (serPlace + 1) * 2;
    }

    public void setSerPlace(int place) {
        serPlace = place;
    }
}