package sample;

public class Generator{

    //Generator Variables
    private String genName;
    private int genValue;
    private double genMulti;
    private int genTotal;
    private int genAmount;
    private int genCost;
    private int genBCost;

    //Upgrade Variables
    private String[] serText = new String[4];
    private int[] serCost = new int[4];
    private int serPlace;

    public int serLength = 4;

    //Constructors
    Generator(String gName, int value, int gCost, String text[], int uCost[]){
        genName = gName;
        genValue = value;
        genBCost = gCost;
        genCost = gCost;

        for(int i = 0; i < serLength; i++) {
            serText[i] = text[i];
            serCost[i] = uCost[i];
        }
        serPlace = 0;
    }

    public void update(){
        genCost = (int) (genBCost * Math.pow(1.2, genAmount));
        genMulti = (serPlace +  1) * 1.5;
        genTotal = (int)((genValue * genMulti + 1) * genAmount);
    }

    //Generator Functions
    public String getGenName(){
        return genName;
    }

    public int getGenTotal(){
        genTotal = (int)((genValue * genMulti + 1) * genAmount);
        return genTotal;
    }

    public int getGenCost(){
        return genCost;
    }

    public int getGenAmount(){
        return genAmount;
    }

    public void setGenAmount(int amount){ genAmount = amount;}

   public long buyGen(long counter){
        if(counter >= genCost){
            genAmount += 1;
            counter -= genCost;
            genCost = (int) (genBCost * Math.pow(1.2, genAmount));
        }
       return counter;
   }

    //Upgrades Functions
    public int getSerPlace(){
        return serPlace;
    }

    public void setSerPlace(int place){serPlace = place;}

    public String getSerText(){
        return serText[serPlace];
    }

    public int getSerCost(){
        return serCost[serPlace];
    }

    boolean isDone = false;
    public long serBuy(long counter){
        if(serPlace == 3 && counter >= serCost[serPlace]) {
            counter -= serCost[serPlace];
            isDone = true;
        }else if (counter >= serCost[serPlace]) {
                counter -= serCost[serPlace];
                serPlace += 1;
                genMulti = (serPlace +  1) * 1.5;
        }
        return counter;
    }
}
