/*
**
*Component is to act as sprite object, holding valuable info
*
*Component Name: Sprite
*Programmer: 
*Version: 1.0 (6/11/2020)
**
*/

package Main;

import java.io.FileInputStream; 
import java.io.FileNotFoundException; 
import javafx.application.Application; 
import javafx.scene.Group; 
import javafx.scene.Scene; 
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;  
import javafx.stage.Stage;  
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class Sprite {
	//variables/clasess
	private Image image;
	private ImageView imageView;
	private FadeTransition ft;
	private int imgHeight;
	private int imgWidth;
	
	//constructor
	Sprite(String file, int width, int height){        
	       
		try {
			image = new Image(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	        imageView = new ImageView(image);
	        imageView.setFitHeight(height);
	        imageView.setFitWidth(width);
	        imageView.setPreserveRatio(true);
	        imgHeight = height;
	        imgWidth = width;
	}
	
	public ImageView getImageView() {
		return imageView;
	}
	
	public Image getImage() {
		return image;
	}
	public int getWidth() {
		return imgWidth;
	}
	public int getHeight() {
		return imgHeight;
	}
	
	
}
