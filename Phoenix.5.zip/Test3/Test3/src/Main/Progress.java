/*
**
*Component is to load in progress during load and run time
*
*Component Name: Progress
*Programmer: 
*Version: 1.0 (6/11/2020)
**
*/
package Main;

public class Progress {
	private int genTrig;
	private int upTrig;
	private Display screen;
	private Sprite phoenix1;
	private Sprite phoenix2;
	private Sprite phoenix3;
	private Sprite phoenix4;
	private Sprite phoenix5;
	private Sprite boat;
	private Sprite IST;
	private Sprite digital;
	private Sprite hello;
	private Sprite engineer;
	
	//constructors
	Progress(){
		genTrig = 0;
		upTrig = 0;
		loadImages();
		changeScene();
	}
	Progress(Display d){
		genTrig = 0;
		upTrig = 0;
		screen = d;
		loadImages();
		changeScene();
	}
	public void setGenTrig(int numb){
		if(numb > genTrig) {
			genTrig = numb;
		}
			changeScene();
		
	}
	public void setUpTrig(int numb) {
		if(numb > upTrig) {
			upTrig = numb;
		}
			changeScene();
		
	}
	
	public void setDisplay(Display d) {
		screen = d;
	}
	//load in assets
	protected void loadImages() {
        phoenix1 = new Sprite("Sprites/phoenix.png",150,150);
        phoenix2 = new Sprite("Sprites/phoenix_glass.png",190,190);
        phoenix3 = new Sprite("Sprites/phoenix_glassRandom.png",220,220);
        phoenix4 = new Sprite("Sprites/phoenix_glass_fire.png",260,260);
        phoenix5 = new Sprite("Sprites/phoenix_glassRandom_fire.png",300,300);
        boat= new Sprite("Sprites/boat.png",150,150);
        IST= new Sprite("Sprites/IST.png",200,200);
        digital= new Sprite("Sprites/digital.png",150,150);
        hello= new Sprite("Sprites/helloworld.png",200,200);
        engineer= new Sprite("Sprites/engineer.png",100,100);
	}
	
	
	public void changeScene() {
		
		screen.changeBackground(2);
	
		
	//change phoenixs sprites
	switch(upTrig) {
	case 0:
	case 1:
	       screen.addImage(phoenix1.getImage(), (300 - phoenix1.getWidth()/2) , 0, phoenix1.getWidth(), phoenix1.getHeight());
		break;
	case 2:
        screen.addImage(phoenix2.getImage(), (300 - phoenix2.getWidth()/2), 0, phoenix2.getWidth(), phoenix2.getHeight());
		break;
	case 3:
		screen.addImage(phoenix3.getImage(), (300 - phoenix3.getWidth()/2), 0, phoenix3.getWidth(), phoenix3.getHeight());
		break;
	case 4:
        screen.addImage(phoenix4.getImage(), (300 - phoenix4.getWidth()/2), 0, phoenix4.getWidth(), phoenix4.getHeight());
		break;
	case 5:
        screen.addImage(phoenix5.getImage(), (300 - phoenix5.getWidth()/2), 0, phoenix5.getWidth(), phoenix5.getHeight());
		break;
	
	}
	//background visuals
	switch(genTrig) {
	case 4:screen.addImage(engineer.getImage(), 400 ,20 , engineer.getWidth(), engineer.getHeight());
	case 3:screen.addImage(digital.getImage(), 50 ,1850 , digital.getWidth(), digital.getHeight());
	case 2:screen.addImage(hello.getImage(), 380 ,140 , hello.getWidth(), hello.getHeight());
	case 1:screen.addImage(boat.getImage(), 0 ,0 , boat.getWidth(), boat.getHeight());
	default:screen.addImage(IST.getImage(), (300 - IST.getWidth()/2) ,220 , IST.getWidth(), IST.getHeight());
		break;
	
	
	
	
	
	
	}
		
		
		
		
		
	}
}
