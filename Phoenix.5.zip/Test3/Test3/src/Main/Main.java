/*
**
*Component is to load in objects
*
*Component Name: Main
*Programmer: 
*Version: 1.0 (6/11/2020)
**
*/
package Main;

import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class Main extends Application {

    Counter counter = new Counter();


    public void start(Stage primaryStage) throws Exception {

    	
    	Display screen = new Display();
    	Progress progress = new Progress(screen);
    	
        int[] cst = new int[4];
        String[] st = new String[5];

        //Making Intro to Stem
        st[0] = "Build a Rube Goldberg Machine";
        st[1] = "Build a Boat";
        st[2] = "Learn About Paper";
        st[3] = "Take a Personality Test";
        cst[0] = 75;
        cst[1] = 150;
        cst[2] = 400;
        cst[3] = 5000;

        Generator ITS = new Generator("Intro to Stem", 1, 25, st, cst);

        //Making Intro to Programing
        st[0] = "Write Hello World";
        st[1] = "Learn Loops";
        st[2] = "Make a Class";
        st[3] = "Make a Calculator";
        cst[0] = 750;
        cst[1] = 1500;
        cst[2] = 2000;
        cst[3] = 10000;

        Generator ITP = new Generator("Intro to Programing", 10, 500, st, cst);

        //Making Digital Media
        st[0] = "Edit Audio";
        st[1] = "Edit Pictures";
        st[2] = "Edit Video";
        st[3] = "Make an AD";
        cst[0] = 2300;
        cst[1] = 4500;
        cst[2] = 6000;
        cst[3] = 50000;

        Generator DM = new Generator("Digital Media", 50, 1700, st, cst);

        //Making Software Engineering
        st[0] = "Group Project";
        st[1] = "Write a SAD Document";
        st[2] = "Make UML Charts";
        st[3] = "Build an Idle Game";
        cst[0] = 12000;
        cst[1] = 15000;
        cst[2] = 25000;
        cst[3] = 1000000;

        Generator SE = new Generator("Software Engineering", 100, 10000, st, cst);

        //Making Button
        st[0] = "Complete Freshman Year";
        st[1] = "Complete Sophomore Year";
        st[2] = "Survive Corona Virus";
        st[3] = "Complete Senior Year";
        cst[0] = 100;
        cst[1] = 500;
        cst[2] = 700;
        cst[3] = 1000;

     
        ClickButton btn = new ClickButton(st, cst);

        final int[] score = {0};
        int test = 1;
        primaryStage.setTitle("Phoenix Clicker");

        Text text1 = new Text(Long.toString(counter.getCounter()));
        text1.setFont(Font.font("Times New Roman", 36));

        Text generatorText = new Text("         generator");
        generatorText.setFont(Font.font("Times New Roman", 20));

        Text upgradeText = new Text("            upgrade");
        upgradeText.setFont(Font.font("Times New Roman", 20));

        Button button1 = new Button("Click");
        button1.setPrefSize(500, 50);
        button1.setMinSize(50, 50);

        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                //counter();
                counter.addCounter(btn.getBtnTotal());
                text1.setText(Long.toString(counter.getCounter()));
                progress.setUpTrig(1);
            }
        });

        
        
      
        
        
        Button introToStem = new Button(ITS.getGenName() + "\nCost: " + ITS.getGenCost() + "\nOwned: " + ITS.getGenAmount());
        introToStem.setPrefSize(200, 100);
        introToStem.setMaxSize(500, 500);

        introToStem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                counter.setCounter(ITS.buyGen(counter.getCounter()));
                introToStem.setText(ITS.getGenName() + "\nCost: " + ITS.getGenCost() + "\nOwned: " + ITS.getGenAmount());               //intro to Stem button
                text1.setText(Long.toString(counter.getCounter()));
                if(ITS.getBought() == 'y') progress.setGenTrig(1);
            }
        });


        Button button2 = new Button(ITP.getGenName() + "\nCost: " + ITP.getGenCost() + "\nOwned: " + ITP.getGenAmount());
        button2.setPrefSize(200, 100);
        button2.setMaxSize(500, 500);

        button2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                counter.setCounter(ITP.buyGen(counter.getCounter()));
                button2.setText(ITP.getGenName() + "\nCost: " + ITP.getGenCost() + "\nOwned: " + ITP.getGenAmount());               //Intro to Programing
                text1.setText(Long.toString(counter.getCounter()));
                if(ITP.getBought() == 'y') progress.setGenTrig(2);
            }
        });


        Button button3 = new Button(DM.getGenName() + "\nCost: " + DM.getGenCost() + "\nOwned: " + DM.getGenAmount());
        button3.setPrefSize(200, 100);
        button3.setMaxSize(500, 500);

        button3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                counter.setCounter(DM.buyGen(counter.getCounter()));
                button3.setText(DM.getGenName() + "\nCost: " + DM.getGenCost() + "\nOwned: " + DM.getGenAmount());               //Digital Media
                text1.setText(Long.toString(counter.getCounter()));
                if(DM.getBought() == 'y') progress.setGenTrig(3);
            }
        });


        Button button4 = new Button(SE.getGenName() + "\nCost: " + SE.getGenCost() + "\nOwned: " + SE.getGenAmount());
        button4.setPrefSize(200, 100);
        button4.setMaxSize(500, 500);

        button4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                counter.setCounter(SE.buyGen(counter.getCounter()));
                button4.setText(SE.getGenName() + "\nCost: " + SE.getGenCost() + "\nOwned: " + SE.getGenAmount());               //Software Engineering
                text1.setText(Long.toString(counter.getCounter()));
                if(SE.getBought() == 'y') progress.setGenTrig(4);
            }
        });


        Button up1 = new Button(ITS.getSerText() + "\nCost: " + ITS.getSerCost());
        up1.setPrefSize(200, 100);
        up1.setMaxSize(500, 500);

        up1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!ITS.isDone) {
                    counter.setCounter(ITS.serBuy(counter.getCounter()));
                    up1.setText(ITS.getSerText() + "\nCost: " + ITS.getSerCost());
                    text1.setText(Long.toString(counter.getCounter()));
                    if (ITS.isDone) {
                    	progress.setUpTrig(2);
                        up1.setText(ITS.getSerText() + "\nPurchased");
                    }
                }

            }
        });


        Button up2 = new Button(ITP.getSerText() + "\nCost: " + ITP.getSerCost());
        up2.setPrefSize(200, 100);
        up2.setMaxSize(500, 500);

        up2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!ITP.isDone) {
                    counter.setCounter(ITP.serBuy(counter.getCounter()));
                    up2.setText(ITP.getSerText() + "\nCost: " + ITP.getSerCost());
                    text1.setText(Long.toString(counter.getCounter()));
                    if (ITP.isDone) {
                    	progress.setUpTrig(3);
                        up2.setText(ITP.getSerText() + "\nPurchased");
                    }
                }
            }
        });


        Button up3 = new Button(DM.getSerText() + "\nCost: " + DM.getSerCost());
        up3.setPrefSize(200, 100);
        up3.setMaxSize(500, 500);

        up3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!DM.isDone) {
                    counter.setCounter(DM.serBuy(counter.getCounter()));
                    up3.setText(DM.getSerText() + "\nCost: " + DM.getSerCost());
                    text1.setText(Long.toString(counter.getCounter()));
                    if (DM.isDone) {
                    	progress.setUpTrig(4);
                        up3.setText(DM.getSerText() + "\nPurchased");
                    }
                }
            }
        });


        Button up4 = new Button(SE.getSerText() + "\nCost: " + SE.getSerCost());
        up4.setPrefSize(200, 100);
        up4.setMaxSize(500, 500);

        up4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!SE.isDone) {
                    counter.setCounter(SE.serBuy(counter.getCounter()));
                    up4.setText(SE.getSerText() + "\nCost: " + SE.getSerCost());
                    text1.setText(Long.toString(counter.getCounter()));
                    if (SE.isDone) {
                    	progress.setUpTrig(5);
                        up4.setText(SE.getSerText() + "\nPurchased");
                    }
                }
            }
        });


        Button up5 = new Button(btn.getSerText() + "\nCost: " + btn.getSerCost());
        up5.setPrefSize(200, 100);
        up5.setMaxSize(500, 500);

        up5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!btn.isDone) {
                    counter.setCounter(btn.serBuy(counter.getCounter()));
                    up5.setText(btn.getSerText() + "\nCost: " + btn.getSerCost());
                    text1.setText(Long.toString(counter.getCounter()));
                    if (btn.isDone) {
                        up5.setText(btn.getSerText() + "\nPurchased");
                    }
                }
            }
        });


        Button Save = new Button("Save");
        Save.setPrefSize(100, 50);
        Save.setMaxSize(500, 500);

        Save.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                File saveFile = new File("../saveFile.txt");

                if (saveFile.exists()) {
                    saveFile.delete();
                }

                try {
                    saveFile.createNewFile();
                    FileWriter writer = new FileWriter("saveFile.txt");
                    writer.write(counter.getCounter() + " " + btn.getSerPlace() + " " + btn.isDone + " " + ITS.getGenAmount() + " " + ITS.getSerPlace() + " " + ITS.isDone + " " + ITP.getGenAmount() + " " + ITP.getSerPlace() + " " + ITP.isDone + " " + DM.getGenAmount() + " " + DM.getSerPlace() + " " + DM.isDone + " " + SE.getGenAmount() + " " + SE.getSerPlace() + " " + SE.isDone);
                    writer.close();
                } catch (IOException ex) {
                    System.out.println("Error making file");
                }
            }
        });

        Button Load = new Button("Load");
        Load.setPrefSize(100, 50);
        Load.setMaxSize(500, 500);

        Load.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                try {
                    File saveFile = new File("saveFile.txt");
                    Scanner reader = new Scanner(saveFile);
                    int data = reader.nextInt();
                    counter.setCounter(data);

                    data = reader.nextInt();
                    btn.setSerPlace(data);
                    Boolean data2 = reader.nextBoolean();
                    btn.isDone = data2;
                    btn.update();
                    if (!btn.isDone) {
                        up5.setText(btn.getSerText() + "\nCost: " + btn.getSerCost());
                    } else {
                        up5.setText(btn.getSerText() + "\nPurchased");
                    }

                    data = reader.nextInt();
                    ITS.setGenAmount(data);
                    if(data > 0)progress.setGenTrig(1); //load in progress does for all Gens
                    introToStem.setText(ITS.getGenName() + "\nCost: " + ITS.getGenCost() + "\nOwned: " + ITS.getGenAmount());
                    data = reader.nextInt();
                    ITS.setSerPlace(data);
                    data2 = reader.nextBoolean();
                    ITS.isDone = data2;
                    ITS.update();
                    if (!ITS.isDone) {
                        up1.setText(ITS.getSerText() + "\nCost: " + ITS.getSerCost());

                    } else {
                        up1.setText(ITS.getSerText() + "\nPurchased");
                        progress.setUpTrig(2);
                    }

                    data = reader.nextInt();
                    ITP.setGenAmount(data);
                    if(data > 0)progress.setGenTrig(2);
                    button2.setText(ITP.getGenName() + "\nCost: " + ITP.getGenCost() + "\nOwned: " + ITP.getGenAmount());
                    data = reader.nextInt();
                    ITP.setSerPlace(data);
                    data2 = reader.nextBoolean();
                    ITP.isDone = data2;
                    ITP.update();
                    if (!ITP.isDone) {
                        up2.setText(ITP.getSerText() + "\nCost: " + ITP.getSerCost());
                    } else {
                        up2.setText(ITP.getSerText() + "\nPurchased");
                        progress.setUpTrig(3);
                    }

                    data = reader.nextInt();
                    DM.setGenAmount(data);
                    if(data > 0)progress.setGenTrig(3);
                    button3.setText(DM.getGenName() + "\nCost: " + DM.getGenCost() + "\nOwned: " + DM.getGenAmount());
                    data = reader.nextInt();
                    DM.setSerPlace(data);
                    data2 = reader.nextBoolean();
                    DM.isDone = data2;
                    DM.update();
                    if (!DM.isDone) {
                        up3.setText(DM.getSerText() + "\nCost: " + DM.getSerCost());
                    } else {
                        up3.setText(DM.getSerText() + "\nPurchased");
                        progress.setUpTrig(4);
                    }

                    data = reader.nextInt();
                    SE.setGenAmount(data);
                    if(data > 0)progress.setGenTrig(4);
                    button4.setText(SE.getGenName() + "\nCost: " + SE.getGenCost() + "\nOwned: " + SE.getGenAmount());
                    data = reader.nextInt();
                    SE.setSerPlace(data);
                    data2 = reader.nextBoolean();
                    SE.isDone = data2;
                    SE.update();
                    if (!SE.isDone) {
                        up4.setText(SE.getSerText() + "\nCost: " + SE.getSerCost());
                    } else {
                        up4.setText(SE.getSerText() + "\nPurchased");
                        progress.setUpTrig(5);
                    }

                    reader.close();
                } catch (FileNotFoundException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
            }
        });


        VBox vbox = new VBox();
        vbox.setSpacing(10);

        vbox.getChildren().add(generatorText);
        vbox.getChildren().add(introToStem);
        vbox.getChildren().add(button2);
        vbox.getChildren().add(button3);
        vbox.getChildren().add(button4);
        vbox.getChildren().add(Save);
        vbox.getChildren().add(Load);

        
        
        

        VBox vbox2 = new VBox();
        vbox2.setSpacing(10);

        vbox2.getChildren().add(upgradeText);
        vbox2.getChildren().add(up1);
        vbox2.getChildren().add(up2);
        vbox2.getChildren().add(up3);
        vbox2.getChildren().add(up4);
        vbox2.getChildren().add(up5);


      screen.setArea(text1, 't');
        screen.setAlignment(text1, "BOTTOM_CENTER");
        screen.setAlignment(button1,"BOTTOM_CENTER");
        screen.setArea(vbox,'l');
        screen.setArea(vbox2,'r');
        screen.setArea(button1, 'b');

        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                Runnable updater = new Runnable() {

                    @Override
                    public void run() {
                        counter.perSecond(ITS.getGenTotal(), ITP.getGenTotal(), DM.getGenTotal(), SE.getGenTotal());
                        text1.setText(Long.toString(counter.getCounter()));
                    }
                };

                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                    }

                    // UI update is run on the Application thread
                    Platform.runLater(updater);
                }
            }

        });
        // don't let thread prevent JVM shutdown
        thread.setDaemon(true);
        thread.start();

        Scene scene = new Scene(screen.getScreen(), 1000, 500);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public void counter() {
        counter.addCounter(1000000);
    }

    public static void main(String[] args) {
        launch(args);
    }
}