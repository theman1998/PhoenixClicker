/*
**
*Component is to keep track of of points earn in game
*
*Component Name: Counter
*Programmer: 
*Version: 1.0 (6/11/2020)
**
*/



package Main;


public class Counter {
    private long counter;
    private long perSecond;

    Counter() {
        counter = 0;
    }

    public long removeCounter(int cost) {
        counter = counter - cost;
        return counter;
    }

    public long addCounter(int added) {
        counter = counter + added;
        return counter;
    }

    public long getCounter() {
        return counter;
    }

    public long setCounter(long number) {
        counter = number;
        return counter;
    }

    public void perSecond(int ITS, int ITP, int DM, int SE) {
        perSecond = ITS + ITP + DM + SE;
        counter += perSecond;
    }

}
